package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.entities.Citizen;
import com.example.demo.entities.VaccinationCenter;
import com.example.demo.repository.CitizenRepository;
import com.example.demo.repository.VaccinationCenterRepository;

@SpringBootApplication
public class VactinationCenter2Application implements CommandLineRunner {

	@Autowired
	private CitizenRepository citizenRepository;
	@Autowired
	private VaccinationCenterRepository vaccinationCenterRepository;
	public static void main(String[] args) {
		SpringApplication.run(VactinationCenter2Application.class, args);
	}
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method s
		Citizen citizen = new Citizen();
		citizen.setCity("CITY_1");
		citizen.setName("NAME_1");
		citizenRepository.save(citizen);
		VaccinationCenter vc = new VaccinationCenter();

		
		vc.setName("CLINIC_1");
		vc.setAddress("BLR1");
		vaccinationCenterRepository.save(vc);
		citizen.setCenter(vc);
		citizenRepository.save(citizen);
	
		
	}
	
}
