package com.example.demo.services;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Citizen;
import com.example.demo.entities.VaccinationCenter;
import com.example.demo.repository.CitizenRepository;
import com.example.demo.repository.VaccinationCenterRepository;

@Service
public class VaccinationCenterService {
@Autowired
private VaccinationCenterRepository vaccinationCenterRepository;
@Autowired
private CitizenRepository citizenRepository;
public VaccinationCenter addOrUpdate(VaccinationCenter center) {
return vaccinationCenterRepository.save(center);
}
public List<VaccinationCenter> getVaccinationCenters() {
List<VaccinationCenter> vaccinationCenters =StreamSupport.stream(vaccinationCenterRepository.findAll().spliterator(), false).collect(Collectors.toList());
return vaccinationCenters;
}
public boolean delete(long id){
VaccinationCenter vaccinationCenter =
vaccinationCenterRepository.findById(id).get();
List<Citizen> citizenList = citizenRepository.findAllByCenterId(id);
citizenList.forEach(e->{
e.setCenter(null);
citizenRepository.save(e);
});
vaccinationCenterRepository.delete(vaccinationCenter);
return true;
}
public VaccinationCenter getVaccinationCenter(long id) {
return vaccinationCenterRepository.findById(id).get();
}
}