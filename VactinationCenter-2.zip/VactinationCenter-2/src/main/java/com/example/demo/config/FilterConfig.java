package com.example.demo.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;

import com.example.demo.filter.UserAuthenticationFilter;
import com.example.demo.repository.UserRepository;

import jakarta.servlet.DispatcherType;

@Configuration
@ComponentScan("com.example.demo.repository")
public class FilterConfig {
@Bean
public FilterRegistrationBean<UserAuthenticationFilter> registrationFilter(@Autowired UserRepository userRepository) {
FilterRegistrationBean<UserAuthenticationFilter> registrationBean =new FilterRegistrationBean<>();
registrationBean.setFilter(new UserAuthenticationFilter(userRepository));
registrationBean.addUrlPatterns("/citizens","/citizens/*","/vaccinationcenter","/vaccinationcenter/*","/me");

registrationBean.setOrder(Ordered.HIGHEST_PRECEDENCE);
registrationBean.setDispatcherTypes(DispatcherType.REQUEST);
return registrationBean;
}


}


