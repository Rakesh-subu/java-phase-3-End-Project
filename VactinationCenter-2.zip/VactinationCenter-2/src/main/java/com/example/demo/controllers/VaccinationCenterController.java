package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.VaccinationCenter;
import com.example.demo.pojo.VaccinationCenterDto;
import com.example.demo.services.VaccinationCenterService;

@RestController
@RequestMapping(value = "vaccinationcenter", produces = "application/json")
public class VaccinationCenterController {
@Autowired
private VaccinationCenterService vaccinationCenterService;
@GetMapping("/{id}")
public VaccinationCenter findVaccinationCenter(@PathVariable long id) {
return vaccinationCenterService.getVaccinationCenter(id);
}
@DeleteMapping("/{id}")
public boolean deleteVaccinationCenter(@PathVariable long id) {
return vaccinationCenterService.delete(id);
}
@GetMapping()
public List<VaccinationCenter> findVaccinationCenters() {
return vaccinationCenterService.getVaccinationCenters();
}
@PostMapping
public VaccinationCenter addNewVaccinationCenter(@Validated @RequestBody VaccinationCenterDto vaccinationCenterDto) {
VaccinationCenter vaccinationCenter = new VaccinationCenter();
vaccinationCenter.setName(vaccinationCenterDto.getName());
vaccinationCenter.setAddress(vaccinationCenterDto.getCity());
return vaccinationCenterService.addOrUpdate(vaccinationCenter);
}
@PutMapping
public VaccinationCenter updateVaccinationCenter(@Validated @RequestBody VaccinationCenterDto vaccinationCenterDto) {
VaccinationCenter vaccinationCenter = vaccinationCenterService.getVaccinationCenter(vaccinationCenterDto.getId());
vaccinationCenter.setName(vaccinationCenterDto.getName());
vaccinationCenter.setAddress(vaccinationCenterDto.getCity());
return vaccinationCenterService.addOrUpdate(vaccinationCenter);
}
}